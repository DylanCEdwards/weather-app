"""
Loads and processes weather data from a CSV file.
"""
import pandas

def load_weather_data(location):
    """
        Load weather data from a CSV file using pandas.

        :param location: Path to the CSV file.
        :return: pandas DataFrame containing the weather data.
        """
    return pandas.read_csv(location)

def get_cities(data):
    """
        Extract unique city names from the weather data.

        :param data: pandas DataFrame containing the weather data.
        :return: List of unique city names.
        """
    cities = data.columns[data.columns.str.contains("_")].str.split("_").str[0].unique().tolist()
    for i in range(len(cities)):
        # Special case since this city name is two words.
        # Prevents second half from being cut off.
        if cities[i] == "DE":
            cities[i] = "DE BILT"

    return cities

