# Module 1 - Phase 2 - Weather Data

## Description

This project practices reading CSV files
and documenting code using Python docstrings, while following
Pythonic coding standards. An understanding of modularization 
has been introduced since the last version. 

---

## Purpose
This project was created as part of CS 3270 to practice
working with pandas DataFrames, modularization and
documentation.

---

## Project Files
- `Module1.py` – Main Python script containing the CSV loading logic
- `WeatherPredictionData/weather_prediction_dataset.csv` – Input data file
- `weather_data.html` – Auto-generated documentation created with `pydoc`
- `README.md` – Project documentation
- `weather_stats/loader.py` - Module for loading & processing weather data from CSV
- `weather_stats/stats.py` - Module for calculating statistics on weather data

---

## Requirements
- Python 3.x
- pandas