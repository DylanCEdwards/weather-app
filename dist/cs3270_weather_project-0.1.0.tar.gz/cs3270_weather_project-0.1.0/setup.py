from setuptools import setup, find_packages

setup(
    name='weather',
version='0.1',
author='',
url='', install_requires=['pandas'])