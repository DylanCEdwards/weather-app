"""
Provides functions to compute various statistical measures
on weather data stored in a pandas DataFrame.
"""
def get_mean(data, column):
    """
    Calculate the mean of a specified column in the data.

    :param data: Pandas DataFrame.
    :param column: String name of the column.
    :return: The mean value of the specified column.
    """
    return data[column].mean()

def get_median(data, column):
    """
    Calculate the median of a specified column in the data.

    :param data: Pandas DataFrame.
    :param column: String name of the column.
    :return: The median value of the specified column.
    """
    return data[column].median()

def get_min(data, column):
    """
    Calculate the minimum value of a specified column in the data.

    :param data: Pandas DataFrame.
    :param column: String name of the column.
    :return: The minimum value of the specified column.
    """
    return data[column].min()

def get_max(data, column):
    """
        Calculate the maximum value of a specified column in the data.

        :param data: Pandas DataFrame.
        :param column: String name of the column.
        :return: The maximum value of the specified column.
        """
    return data[column].max()

def get_std_dev(data, column):
    """
        Calculate the standard deviation from values of a specified column in the data.

        :param data: Pandas DataFrame.
        :param column: String name of the column.
        :return: The standard deviation of the specified column.
        """
    return data[column].std()

def get_range(data, column):
    """
        Calculate the range of a specified column in the data.

        :param data: Pandas DataFrame.
        :param column: String name of the column.
        :return: The range (max value less min value) of the specified column.
        """
    return get_max(data, column) - get_min(data, column)

def get_mode(data, column):
    """
        Calculate the mode value of a specified column in the data.

        :param data: Pandas DataFrame.
        :param column: String name of the column.
        :return: The mode (most repeated) value of the specified column.
        """
    return data[column].mode()[0]

